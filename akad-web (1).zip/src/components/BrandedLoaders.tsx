import React from "react";

interface LoaderProps {
  text?: string;
  className?: string;
}

/**
 * Loader 1: Ring of Time (Rotating 3D Dots Circle)
 * Styled with Akad Web's emerald green and deep dark tones.
 */
export const PlLoader: React.FC<LoaderProps> = ({ text = "AKAD", className = "" }) => {
  return (
    <div className={`flex items-center justify-center py-6 ${className}`}>
      <div className="pl">
        {/* 12 orbiting dots with staggered delays in CSS */}
        <div className="pl__dot" />
        <div className="pl__dot" />
        <div className="pl__dot" />
        <div className="pl__dot" />
        <div className="pl__dot" />
        <div className="pl__dot" />
        <div className="pl__dot" />
        <div className="pl__dot" />
        <div className="pl__dot" />
        <div className="pl__dot" />
        <div className="pl__dot" />
        <div className="pl__dot" />
        
        {/* Core text rotating in the opposite perspective */}
        <div className="pl__text">{text}</div>
      </div>
    </div>
  );
};

/**
 * Loader 2: Scrolling Text Wave (Cylindrical Sliced Perspective)
 * Slices a word vertically and scrolls gradients through it in pseudo-3D.
 */
export const TextWaveLoader: React.FC<LoaderProps> = ({ text = "AKAD WEB", className = "" }) => {
  // We repeat the text across 9 vertical slices to match the 3D clipping
  const slices = Array(9).fill(text);

  return (
    <div className={`flex flex-col items-center justify-center py-6 ${className}`}>
      <div className="loader">
        {slices.map((sliceText, index) => (
          <div key={index} className="text">
            <span>{sliceText}</span>
          </div>
        ))}
      </div>
      {/* Small loading indicator bar at the bottom */}
      <div className="loader mt-2 h-2 flex items-center justify-center">
        <div className="line" />
      </div>
    </div>
  );
};
